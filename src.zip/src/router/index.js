import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const login =()=>import ("@/views/login/index")
const home =()=>import ("@/views/main/index")

export default new Router({
  routes: [
    {
      path:"/",
      redirect:"/login"
    },
    {
      path:"/login",
      component:login
    },
    {
      path:"/home",
      component:home
    }
  ]
})
