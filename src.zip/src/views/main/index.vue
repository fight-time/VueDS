<template>
  <div id="Main">
    这是主页
  
  </div>
</template>

<script>
export default {
  name: 'Main',
  components:{
  }
}
</script>

<style>
</style>
