<template>
  <div id="Login">
    <el-form ref="form" :model="form" :rules="loginFormRules" label-width="80px">
      <el-form-item label="用户名" prop="username">
        <el-input v-model="form.username"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input v-model="form.password" type="password"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="onSubmit" type="success">登录</el-button>
        <el-button type="info" round>重置</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: 'Login',
  data() {
      return {
        form: {
          username: '',
          password:'',
        },
        loginFormRules:{
          username: [
            { required: true, message: '请输入账号', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
          password: [
            { required: true, message: '请输入密码', trigger: 'blur' },
            { min: 3, max: 10, message: '长度在 3 到 10 个字符', trigger: 'blur' }
          ],
        }
      }
    },
    methods: {
      onSubmit() {
      this.$store.dispatch("loginByUsername", this.form).then((res) => {
        this.$router.push({ path: "/home" });
      });
    }
    }
}
</script>

<style scoped>
#Login{
  width: 500px;
  height: 50px;
  margin: 0 auto;
  margin-top:100px ;
}
</style>
